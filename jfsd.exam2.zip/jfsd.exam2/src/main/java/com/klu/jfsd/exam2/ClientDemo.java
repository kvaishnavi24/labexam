package com.klu.jfsd.exam2;
package com.klu.jfsd.exam2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import javax.persistence.criteria.*;

public class ClientDemo {
    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();

            // Insert records
            Project project1 = new Project("AI Model", 12, 500000, "Alice");
            Project project2 = new Project("Web App", 6, 200000, "Bob");
            Project project3 = new Project("Data Pipeline", 8, 300000, "Charlie");

            session.persist(project1);
            session.persist(project2);
            session.persist(project3);

            transaction.commit();
            System.out.println("Projects successfully inserted into the database.");

            // Perform aggregate operations using CriteriaQuery
            performAggregateOperations(session);

        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
            sessionFactory.close();
        }
    }

    private static void performAggregateOperations(Session session) {
        System.out.println("\nPerforming aggregate operations using CriteriaQuery:");

        CriteriaBuilder cb = session.getCriteriaBuilder();

        // Count
        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<Project> rootCount = countQuery.from(Project.class);
        countQuery.select(cb.count(rootCount));
        Long totalProjects = session.createQuery(countQuery).getSingleResult();
        System.out.println("Total Projects: " + totalProjects);

        // Max Budget
        CriteriaQuery<Double> maxQuery = cb.createQuery(Double.class);
        Root<Project> rootMax = maxQuery.from(Project.class);
        maxQuery.select(cb.max(rootMax.get("budget").as(Double.class)));
        Double maxBudget = session.createQuery(maxQuery).getSingleResult();
        System.out.println("Max Budget: " + maxBudget);

        // Min Budget
        CriteriaQuery<Double> minQuery = cb.createQuery(Double.class);
        Root<Project> rootMin = minQuery.from(Project.class);
        minQuery.select(cb.min(rootMin.get("budget").as(Double.class)));
        Double minBudget = session.createQuery(minQuery).getSingleResult();
        System.out.println("Min Budget: " + minBudget);

        // Sum Budget
        CriteriaQuery<Double> sumQuery = cb.createQuery(Double.class);
        Root<Project> rootSum = sumQuery.from(Project.class);
        sumQuery.select(cb.sum(rootSum.get("budget").as(Double.class)));
        Double totalBudget = session.createQuery(sumQuery).getSingleResult();
        System.out.println("Total Budget: " + totalBudget);

        // Average Budget
        CriteriaQuery<Double> avgQuery = cb.createQuery(Double.class);
        Root<Project> rootAvg = avgQuery.from(Project.class);
        avgQuery.select(cb.avg(rootAvg.get("budget").as(Double.class)));
        Double avgBudget = session.createQuery(avgQuery).getSingleResult();
        System.out.println("Average Budget: " + avgBudget);
    }

}
